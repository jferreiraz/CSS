# Formulario-HTML-com-CSS
Formulário HTML com inserção de dados ( nome, email, telefone, senha e confirmação + gênero ), stylezado com CSS
